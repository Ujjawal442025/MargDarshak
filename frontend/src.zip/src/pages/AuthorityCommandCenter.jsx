import React, { useState, useMemo, useEffect } from 'react';
import {
  Shield,
  Activity,
  AlertTriangle,
  Users,
  Compass,
  TrendingUp,
  Clock,
  ArrowRight,
  Sliders,
  CheckCircle2,
  XCircle,
  Sparkles,
  MapPin,
  RefreshCw,
  Play,
  RotateCcw,
  Zap,
  ExternalLink,
  ChevronRight,
  Send
} from 'lucide-react';
import { destinations } from '../data/destinations';
import { authorityKPIs, initialIncidents, mockDestinationTelemetry, getAuthoritySiteTelemetry } from '../data/authorityData';
import { rajasthanEvents } from '../data/events';

export default function AuthorityCommandCenter() {
  const [selectedSiteId, setSelectedSiteId] = useState("RJ_AMBER_FORT");
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());
  const [executedActions, setExecutedActions] = useState([]);
  const [actionSuccessMsg, setActionSuccessMsg] = useState("");
  const [activeTab, setActiveTab] = useState("OVERVIEW");
  const [selectedIncident, setSelectedIncident] = useState(initialIncidents[0]);
  const [simulationParams, setSimulationParams] = useState({
    gate1Closure: true,
    touristInflowDeltaPct: 25,
    weatherRainAlert: false
  });
  const [actionCheckboxes, setActionCheckboxes] = useState({
    redirectTourists: true,
    deployPersonnel: true,
    monitorGate: true,
    issueAlert: false
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const currentTelemetry = getAuthoritySiteTelemetry(selectedSiteId);
  const selectedDestination = destinations.find(d => d.site_id === selectedSiteId) || destinations[2];

  const mapHotspots = useMemo(() => {
    return [
      { id: "RJ_AMBER_FORT", name: "Amber Fort", city: "Jaipur", x: 68, y: 35, status: "HIGH", count: "82%", queue: 71 },
      { id: "RJ_HAWA_MAHAL", name: "Hawa Mahal", city: "Jaipur", x: 70, y: 37, status: "HIGH", count: "81%", queue: 58 },
      { id: "RJ_JAIGARH_FORT", name: "Jaigarh Fort", city: "Jaipur", x: 67, y: 34, status: "LOW", count: "45%", queue: 8 },
      { id: "RJ_CITY_PALACE_UDAIPUR", name: "City Palace", city: "Udaipur", x: 38, y: 76, status: "HIGH", count: "81%", queue: 54 },
      { id: "RJ_MEHRANGARH_FORT", name: "Mehrangarh Fort", city: "Jodhpur", x: 34, y: 48, status: "MODERATE", count: "68%", queue: 28 },
      { id: "RJ_JAISALMER_FORT", name: "Jaisalmer Fort", city: "Jaisalmer", x: 14, y: 42, status: "HIGH", count: "87%", queue: 64 },
      { id: "RJ_KHATU_SHYAM", name: "Khatu Shyam", city: "Sikar", x: 62, y: 28, status: "CRITICAL", count: "92%", queue: 195 },
      { id: "RJ_PUSHKAR", name: "Pushkar Ghats", city: "Ajmer", x: 50, y: 46, status: "EVENT", count: "85%", queue: 92 },
      { id: "RJ_RANTHAMBORE_NATIONAL_PARK", name: "Ranthambore", city: "Sawai Madhopur", x: 74, y: 55, status: "NORMAL", count: "60%", queue: 15 },
      { id: "RJ_JUNAGARH_FORT", name: "Junagarh Fort", city: "Bikaner", x: 36, y: 24, status: "NORMAL", count: "59%", queue: 12 },
      { id: "RJ_CHITTORGARH_FORT", name: "Chittorgarh Fort", city: "Chittorgarh", x: 48, y: 68, status: "MODERATE", count: "72%", queue: 32 },
      { id: "RJ_KUMBHALGARH_FORT", name: "Kumbhalgarh", city: "Rajsamand", x: 35, y: 65, status: "NORMAL", count: "58%", queue: 14 }
    ];
  }, []);

  const handleExecuteActions = (siteName) => {
    const newAction = {
      id: `ACT-${Date.now().toString().slice(-4)}`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      siteName: siteName || currentTelemetry.siteName,
      actions: Object.entries(actionCheckboxes)
        .filter(([_, val]) => val)
        .map(([key]) => {
          if (key === 'redirectTourists') return 'Rerouted 30% flow to Gate 2';
          if (key === 'deployPersonnel') return 'Dispatched +3 crowd marshals';
          if (key === 'monitorGate') return 'Activated Gate 1 sensor telemetry';
          if (key === 'issueAlert') return 'Public app advisory broadcasted';
          return key;
        })
    };

    setExecutedActions([newAction, ...executedActions]);
    setActionSuccessMsg(`Tactical actions approved and deployed to ${newAction.siteName} field units!`);
    setTimeout(() => setActionSuccessMsg(""), 4500);
  };

  return (
    <div className="min-h-screen bg-[#0B0F19] text-slate-100 font-sans pb-16">
      {/* Top Operations Banner */}
      <div className="bg-[#111827] border-b border-slate-800/90 px-4 sm:px-6 lg:px-8 py-3.5 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-black text-sm">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black tracking-widest uppercase text-slate-400">
                  Government of Rajasthan • Department of Tourism
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  System Operational
                </span>
              </div>
              <h1 className="font-serif-title text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
                MargDarshak — Rajasthan Tourism Intelligence Authority Command Center
                <span className="text-[10px] font-mono text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800">
                  SIH26204
                </span>
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-400">
            <div className="flex items-center gap-1.5 bg-slate-900/80 px-3 py-1.5 rounded-lg border border-slate-800">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>Real-time Telemetry: <strong className="text-slate-200 font-mono">{currentTime}</strong></span>
            </div>
            <button
              onClick={() => {
                setCurrentTime(new Date().toLocaleTimeString());
                setActionSuccessMsg("Refreshed operational telemetry across 113 destinations.");
                setTimeout(() => setActionSuccessMsg(""), 3000);
              }}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Refresh Feeds"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {actionSuccessMsg && (
        <div className="bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs px-4 py-2.5 max-w-7xl mx-auto mt-4 rounded-xl flex items-center justify-between animate-fade-in shadow-lg">
          <div className="flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{actionSuccessMsg}</span>
          </div>
          <span className="text-[10px] uppercase font-bold text-emerald-400">Logged to Incident Register</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">
        {/* KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-[#131B2E] border border-slate-800/80 rounded-2xl p-4 shadow-sm">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Monitored Sites</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-white font-mono">{authorityKPIs.totalDestinations}</span>
              <span className="text-[10px] text-slate-500">Destinations</span>
            </div>
            <p className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> 33 Districts Active
            </p>
          </div>

          <div className="bg-[#131B2E] border border-amber-900/40 rounded-2xl p-4 shadow-sm">
            <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block">High Crowd</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-amber-400 font-mono">08</span>
              <span className="text-[10px] text-slate-400">&gt;75% Capacity</span>
            </div>
            <p className="text-[10px] text-amber-300 mt-1">Amer, Udaipur, Sonar Qila</p>
          </div>

          <div className="bg-[#131B2E] border border-rose-900/50 rounded-2xl p-4 shadow-sm">
            <span className="text-[10px] uppercase font-bold tracking-wider text-rose-400 block">Critical Pressure</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-rose-500 font-mono">03</span>
              <span className="text-[10px] text-slate-400">Threshold Breaches</span>
            </div>
            <p className="text-[10px] text-rose-300 mt-1 font-semibold">Khatu Shyam, Pushkar Ghats</p>
          </div>

          <div className="bg-[#131B2E] border border-blue-900/40 rounded-2xl p-4 shadow-sm">
            <span className="text-[10px] uppercase font-bold tracking-wider text-blue-400 block">Active Events</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-blue-400 font-mono">12</span>
              <span className="text-[10px] text-slate-400">Festivals / Fairs</span>
            </div>
            <p className="text-[10px] text-blue-300 mt-1">Pushkar, Desert Mela</p>
          </div>

          <div className="bg-[#131B2E] border border-slate-800/80 rounded-2xl p-4 shadow-sm">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Active Incidents</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-orange-400 font-mono">06</span>
              <span className="text-[10px] text-slate-400">Under Action</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-1">Queue &amp; Traffic bottlenecks</p>
          </div>

          <div className="bg-[#131B2E] border border-slate-800/80 rounded-2xl p-4 shadow-sm">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Redistribution</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-emerald-400 font-mono">34%</span>
              <span className="text-[10px] text-slate-400">Shift to Alt Sites</span>
            </div>
            <p className="text-[10px] text-emerald-400 mt-1">Jaigarh, Nahargarh intake ↑</p>
          </div>
        </div>

        {/* Main Command Center Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-[#111827] border border-slate-800 rounded-3xl p-5 shadow-md relative overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4 mb-4">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block">
                    Geospatial Situational Awareness
                  </span>
                  <h2 className="font-serif-title text-base sm:text-lg font-bold text-white flex items-center gap-2">
                    <Compass className="w-4 h-4 text-amber-500" />
                    Live Rajasthan Tourism Operations Grid
                  </h2>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 text-[10px] font-semibold text-slate-300">
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500"></span> Normal</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500"></span> Moderate</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-orange-500"></span> High</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-rose-500"></span> Critical</span>
                  <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500"></span> Event</span>
                </div>
              </div>

              <div className="relative w-full h-[360px] sm:h-[420px] bg-[#0B0F19] rounded-2xl border border-slate-800/80 overflow-hidden flex items-center justify-center p-4">
                <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <polygon points="12,38 35,15 75,18 92,35 88,68 62,88 32,82 18,65" fill="#C59A45" stroke="#C59A45" strokeWidth="0.5" />
                  <line x1="68" y1="35" x2="67" y2="34" stroke="#F59E0B" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
                  <line x1="68" y1="35" x2="70" y2="37" stroke="#EF4444" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
                  <line x1="50" y1="46" x2="68" y2="35" stroke="#3B82F6" strokeWidth="0.6" strokeDasharray="2 2" />
                </svg>

                <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293715_1px,transparent_1px),linear-gradient(to_bottom,#1f293715_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none"></div>

                {mapHotspots.map((spot) => {
                  const isSelected = selectedSiteId === spot.id;
                  let colorBg = "bg-emerald-500";
                  let borderRing = "ring-emerald-500/30";
                  if (spot.status === "CRITICAL") { colorBg = "bg-rose-500"; borderRing = "ring-rose-500/50 animate-ping"; }
                  else if (spot.status === "HIGH") { colorBg = "bg-orange-500"; borderRing = "ring-orange-500/40"; }
                  else if (spot.status === "MODERATE") { colorBg = "bg-amber-500"; borderRing = "ring-amber-500/30"; }
                  else if (spot.status === "EVENT") { colorBg = "bg-blue-500"; borderRing = "ring-blue-500/40 animate-pulse"; }

                  return (
                    <div
                      key={spot.id}
                      style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
                      onClick={() => setSelectedSiteId(spot.id)}
                      className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-20"
                    >
                      <div className={`relative flex items-center justify-center p-1 rounded-full transition-transform ${isSelected ? 'scale-125' : 'hover:scale-110'}`}>
                        <span className={`w-3.5 h-3.5 rounded-full ${colorBg} flex items-center justify-center shadow-lg`}>
                          <span className={`w-1.5 h-1.5 rounded-full bg-white`}></span>
                        </span>
                        <span className={`absolute inset-0 rounded-full ring-4 ${borderRing}`}></span>
                      </div>

                      <div className={`absolute left-1/2 -translate-x-1/2 mt-1 whitespace-nowrap px-2 py-0.5 rounded-md text-[10px] font-bold border transition-all pointer-events-none ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md z-30'
                          : 'bg-[#111827]/90 text-slate-200 border-slate-700/80 group-hover:bg-slate-900'
                      }`}>
                        {spot.name} <span className="opacity-80">({spot.count})</span>
                      </div>
                    </div>
                  );
                })}

                <div className="absolute bottom-3 left-3 bg-[#111827]/90 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 text-[10px] text-slate-400 space-y-1">
                  <div className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Activity className="w-3 h-3 text-amber-400" />
                    <span>Selected: <strong className="text-white">{currentTelemetry.siteName} ({currentTelemetry.city})</strong></span>
                  </div>
                  <div>Live Capacity Utilization: <strong className="text-amber-400">{currentTelemetry.currentCrowdPct}%</strong> | Inflow: <strong className="text-white">+{currentTelemetry.flow.enteringPerMin}/min</strong></div>
                </div>

                <div className="absolute top-3 left-3 hidden sm:flex items-center gap-2 bg-[#111827]/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-[10px] text-slate-300">
                  <span className="text-emerald-400 font-bold">Jaigarh (45%)</span>
                  <span className="text-slate-500">↓ (Reroute)</span>
                  <span className="text-rose-400 font-black">Amber Fort (82% 🔴)</span>
                  <span className="text-slate-500">↓↓</span>
                  <span className="text-amber-400 font-bold">Jaipur Old City</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 font-medium">Selected Choke-Point:</span>
                  <strong className="text-white font-bold bg-slate-800 px-2.5 py-1 rounded-md">
                    {currentTelemetry.siteName} — {currentTelemetry.zone}
                  </strong>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    currentTelemetry.status === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400' : 'bg-orange-500/20 text-orange-400'
                  }`}>
                    {currentTelemetry.status} PRESSURE
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab("SIMULATOR")}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1 transition-colors"
                  >
                    <Sliders className="w-3.5 h-3.5 text-amber-400" />
                    <span>Simulate Scenario</span>
                  </button>
                  <button
                    onClick={() => handleExecuteActions(currentTelemetry.siteName)}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-1 transition-colors shadow-md shadow-amber-600/20"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Execute Interventions</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#111827] border border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Directional Dynamics</span>
                    <h3 className="font-bold text-white text-sm">Gate Crowd Flow &amp; Accumulation</h3>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Net: +{currentTelemetry.flow.netAccumulationPerMin} / min
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Entry Flow</span>
                    <p className="text-base font-black text-emerald-400 font-mono mt-1 flex items-center justify-center gap-0.5">
                      {currentTelemetry.flow.enteringPerMin} <span className="text-xs">/m ↑</span>
                    </p>
                    <span className="text-[9px] text-slate-500">Turnstile Line</span>
                  </div>

                  <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Exit Flow</span>
                    <p className="text-base font-black text-slate-300 font-mono mt-1 flex items-center justify-center gap-0.5">
                      {currentTelemetry.flow.leavingPerMin} <span className="text-xs">/m ↓</span>
                    </p>
                    <span className="text-[9px] text-slate-500">Out-turn clearance</span>
                  </div>

                  <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Active Queue</span>
                    <p className="text-base font-black text-amber-400 font-mono mt-1">
                      {currentTelemetry.flow.queueLength}
                    </p>
                    <span className="text-[9px] text-slate-500">~{currentTelemetry.flow.estimatedWaitMin}m Wait</span>
                  </div>
                </div>

                <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800/80 text-[11px] text-slate-300 flex items-center justify-between">
                  <span>Capacity Saturation: <strong className="text-white">{currentTelemetry.flow.capacityUtilization}%</strong></span>
                  <span className="font-bold text-amber-400">Pressure: {currentTelemetry.flow.density}</span>
                </div>
              </div>

              <div className="bg-[#111827] border border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-rose-400 block">60-Min Ingress Forecast</span>
                    <h3 className="font-bold text-white text-sm">Predictive Density Trajectory</h3>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">Confidence: {currentTelemetry.confidence}</span>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2.5 bg-[#0B0F19] rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">NOW</span>
                    <p className="font-black text-white text-sm font-mono mt-0.5">{currentTelemetry.currentCrowdPct}%</p>
                    <span className="text-[9px] text-orange-400 font-bold">HIGH</span>
                  </div>
                  <div className="p-2.5 bg-[#0B0F19] rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">+15 MIN</span>
                    <p className="font-black text-orange-400 text-sm font-mono mt-0.5">{currentTelemetry.forecast15m}%</p>
                    <span className="text-[9px] text-rose-400 font-bold">SURGE ↑</span>
                  </div>
                  <div className="p-2.5 bg-[#0B0F19] rounded-xl border border-rose-950/60 bg-rose-950/20">
                    <span className="text-[10px] text-rose-400 font-bold block">+30 MIN</span>
                    <p className="font-black text-rose-500 text-sm font-mono mt-0.5">{currentTelemetry.forecast30m}%</p>
                    <span className="text-[9px] text-rose-400 font-black">BREACH 🔴</span>
                  </div>
                  <div className="p-2.5 bg-[#0B0F19] rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">+60 MIN</span>
                    <p className="font-black text-slate-200 text-sm font-mono mt-0.5">{currentTelemetry.forecast60m}%</p>
                    <span className="text-[9px] text-slate-400">RECOVERY</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Contributing Threat Drivers:</span>
                  {currentTelemetry.factors.map((f, i) => (
                    <div key={i} className="flex items-center justify-between text-[11px] px-2 py-1 bg-[#0B0F19] rounded-lg">
                      <span className="text-slate-300">• {f.name}</span>
                      <span className="font-bold text-amber-400">{f.status}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-[#111827] border border-amber-500/30 rounded-3xl p-5 shadow-lg relative overflow-hidden space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm">AI Operations Copilot</h3>
                    <p className="text-[10px] text-slate-400">Autonomous Threat &amp; Action Advisor</p>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  LIVE ADVISORY
                </span>
              </div>

              <div className="p-3.5 bg-rose-950/20 border border-rose-800/40 rounded-2xl text-xs space-y-2">
                <div className="flex items-center gap-2 text-rose-400 font-bold">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Threshold Alert: {currentTelemetry.siteName}</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  Projected to exceed safe operating limit (94% capacity) in <strong>22 minutes</strong> at {currentTelemetry.zone}.
                </p>
              </div>

              <div className="space-y-2 text-xs">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Recommended Interventions:
                </span>
                <ul className="space-y-2">
                  <li className="p-2 bg-[#0B0F19] rounded-xl border border-slate-800/80 flex items-start gap-2 text-slate-300 text-[11px]">
                    <span className="text-amber-400 font-bold">1.</span>
                    <span>Redirect incoming tour bus arrivals toward Gate 2 entrance.</span>
                  </li>
                  <li className="p-2 bg-[#0B0F19] rounded-xl border border-slate-800/80 flex items-start gap-2 text-slate-300 text-[11px]">
                    <span className="text-amber-400 font-bold">2.</span>
                    <span>Deploy 3 crowd-control marshals from Jaigarh Fort staging area.</span>
                  </li>
                  <li className="p-2 bg-[#0B0F19] rounded-xl border border-slate-800/80 flex items-start gap-2 text-slate-300 text-[11px]">
                    <span className="text-amber-400 font-bold">3.</span>
                    <span>Push in-app alerts promoting Jaigarh Fort as calm alternative (-35% queue).</span>
                  </li>
                </ul>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={() => handleExecuteActions(currentTelemetry.siteName)}
                  className="flex-1 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors shadow-md flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Approve &amp; Deploy</span>
                </button>
                <button
                  onClick={() => setActiveTab("SIMULATOR")}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors"
                >
                  Simulate
                </button>
              </div>
            </div>

            <div className="bg-[#111827] border border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <h3 className="font-bold text-white text-sm">Action Execution Center</h3>
                <span className="text-[10px] text-amber-400 font-bold">Active Protocol</span>
              </div>

              <div className="space-y-2.5 text-xs text-slate-300">
                <label className="flex items-center gap-2.5 p-2 rounded-xl bg-[#0B0F19] cursor-pointer hover:bg-slate-800/60 transition-colors">
                  <input
                    type="checkbox"
                    checked={actionCheckboxes.redirectTourists}
                    onChange={(e) => setActionCheckboxes({ ...actionCheckboxes, redirectTourists: e.target.checked })}
                    className="rounded accent-amber-500 w-4 h-4"
                  />
                  <span>Reroute 30% flow to Gate 2 bypass</span>
                </label>

                <label className="flex items-center gap-2.5 p-2 rounded-xl bg-[#0B0F19] cursor-pointer hover:bg-slate-800/60 transition-colors">
                  <input
                    type="checkbox"
                    checked={actionCheckboxes.deployPersonnel}
                    onChange={(e) => setActionCheckboxes({ ...actionCheckboxes, deployPersonnel: e.target.checked })}
                    className="rounded accent-amber-500 w-4 h-4"
                  />
                  <span>Deploy 3 marshals to Suraj Pol choke</span>
                </label>

                <label className="flex items-center gap-2.5 p-2 rounded-xl bg-[#0B0F19] cursor-pointer hover:bg-slate-800/60 transition-colors">
                  <input
                    type="checkbox"
                    checked={actionCheckboxes.monitorGate}
                    onChange={(e) => setActionCheckboxes({ ...actionCheckboxes, monitorGate: e.target.checked })}
                    className="rounded accent-amber-500 w-4 h-4"
                  />
                  <span>Sensor threshold tracking at Parking B</span>
                </label>

                <label className="flex items-center gap-2.5 p-2 rounded-xl bg-[#0B0F19] cursor-pointer hover:bg-slate-800/60 transition-colors">
                  <input
                    type="checkbox"
                    checked={actionCheckboxes.issueAlert}
                    onChange={(e) => setActionCheckboxes({ ...actionCheckboxes, issueAlert: e.target.checked })}
                    className="rounded accent-amber-500 w-4 h-4"
                  />
                  <span>Issue public advisory on tourist app</span>
                </label>
              </div>

              <button
                onClick={() => handleExecuteActions(currentTelemetry.siteName)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-amber-600 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Execute Selected Actions</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="bg-[#111827] border border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <h3 className="font-bold text-white text-sm">Dynamic Resource Balancing</h3>
                <span className="text-[10px] text-emerald-400 font-bold">Source: {currentTelemetry.resources.donorSite}</span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Target Site: {currentTelemetry.siteName}</span>
                    <strong className="text-white text-xs">Security: 12 → 15 (+3)</strong>
                  </div>
                  <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded">In Transit</span>
                </div>

                <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Traffic Units</span>
                    <strong className="text-white text-xs">Traffic: 4 → 7 (+3)</strong>
                  </div>
                  <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded">Deploying</span>
                </div>

                <p className="text-[10px] text-slate-400 leading-relaxed pt-1">
                  Reason: {currentTelemetry.resources.reason} Donor source {currentTelemetry.resources.donorSite} retains safe baseline security ({currentTelemetry.resources.donorSiteChanges.security}).
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM SECTION */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#111827] border border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block">Predictive Scenario Sandbox</span>
                <h3 className="font-serif-title text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-500" />
                  What-If Contingency Simulator
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">Target: {currentTelemetry.siteName}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800 space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 block">Scenario 1: Gate 1 Status</span>
                <button
                  onClick={() => setSimulationParams({ ...simulationParams, gate1Closure: !simulationParams.gate1Closure })}
                  className={`w-full py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                    simulationParams.gate1Closure
                      ? 'bg-rose-600 text-white'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {simulationParams.gate1Closure ? 'Simulate 20m Closure' : 'Gate 1 Open (Nominal)'}
                </button>
              </div>

              <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800 space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 block">Scenario 2: Bus Inflow Surge</span>
                <button
                  onClick={() => setSimulationParams({
                    ...simulationParams,
                    touristInflowDeltaPct: simulationParams.touristInflowDeltaPct === 25 ? 50 : 25
                  })}
                  className="w-full py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold transition-all"
                >
                  +{simulationParams.touristInflowDeltaPct}% Ingress Inflow
                </button>
              </div>

              <div className="p-3 bg-[#0B0F19] rounded-xl border border-slate-800 space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 block">Scenario 3: Weather Anomaly</span>
                <button
                  onClick={() => setSimulationParams({ ...simulationParams, weatherRainAlert: !simulationParams.weatherRainAlert })}
                  className={`w-full py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                    simulationParams.weatherRainAlert
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {simulationParams.weatherRainAlert ? 'Heavy Rain Alert Active' : 'Clear Weather (Dry)'}
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                    <th className="pb-2 font-bold">Operational Metric</th>
                    <th className="pb-2 font-bold">Current Baseline</th>
                    <th className="pb-2 font-bold">Simulated Projection</th>
                    <th className="pb-2 font-bold text-right">Predicted Delta</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                  <tr>
                    <td className="py-2.5 font-sans font-medium text-slate-200">Gate 2 Alternate Load</td>
                    <td className="py-2.5">61%</td>
                    <td className="py-2.5 text-amber-400 font-bold">{simulationParams.gate1Closure ? '84%' : '65%'}</td>
                    <td className="py-2.5 text-right text-rose-400 font-bold">+{simulationParams.gate1Closure ? '23%' : '4%'} ↑</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-sans font-medium text-slate-200">Main Entrance Queue</td>
                    <td className="py-2.5">71 persons</td>
                    <td className="py-2.5 text-orange-400 font-bold">{simulationParams.gate1Closure ? '103 persons' : '75 persons'}</td>
                    <td className="py-2.5 text-right text-rose-400 font-bold">+{simulationParams.gate1Closure ? '32' : '4'} persons ↑</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-sans font-medium text-slate-200">Average Wait Time</td>
                    <td className="py-2.5">24 min</td>
                    <td className="py-2.5 text-rose-400 font-bold">{simulationParams.gate1Closure ? '39 min' : '26 min'}</td>
                    <td className="py-2.5 text-right text-rose-400 font-bold">+{simulationParams.gate1Closure ? '15 min' : '2 min'} ↑</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-sans font-medium text-slate-200">Surrounding Highway Congestion</td>
                    <td className="py-2.5 font-sans">Medium</td>
                    <td className="py-2.5 font-sans text-rose-400 font-bold">{simulationParams.gate1Closure ? 'Severe Bottleneck' : 'Medium'}</td>
                    <td className="py-2.5 text-right font-sans text-amber-400">Degraded</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-xs flex items-center justify-between gap-3">
              <span className="text-amber-200 font-medium">
                <strong>Simulated AI Conclusion:</strong> Do not close Gate 1 completely. Instead, enforce a 30% diversion to Gate 2 to prevent severe highway gridlock.
              </span>
              <button
                onClick={() => handleExecuteActions(currentTelemetry.siteName)}
                className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-xs shrink-0 transition-colors"
              >
                Apply Scenario Solution
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#111827] border border-slate-800 rounded-3xl p-6 shadow-sm space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Field Surveillance</span>
                  <h3 className="font-serif-title text-base font-bold text-white">Live Incident Register &amp; Feed</h3>
                </div>
                <span className="text-[10px] font-bold text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                  {initialIncidents.length} Active
                </span>
              </div>

              <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                {initialIncidents.map((inc) => (
                  <div
                    key={inc.id}
                    onClick={() => {
                      setSelectedIncident(inc);
                      setSelectedSiteId(inc.siteId);
                    }}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all text-xs ${
                      selectedIncident?.id === inc.id
                        ? 'bg-slate-800/90 border-amber-500/70 shadow-md'
                        : 'bg-[#0B0F19] border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        inc.severity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400' : (inc.severity === 'HIGH' ? 'bg-orange-500/20 text-orange-400' : 'bg-amber-500/20 text-amber-400')
                      }`}>
                        {inc.severity}
                      </span>
                      <span className="text-[10px] text-slate-500">{inc.time}</span>
                    </div>
                    <strong className="text-white block font-bold text-xs">{inc.siteName} — {inc.title}</strong>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">{inc.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {selectedIncident && (
              <div className="mt-3 pt-3 border-t border-slate-800 text-xs bg-[#0B0F19] p-3 rounded-xl space-y-1.5">
                <span className="text-[10px] font-bold uppercase text-amber-400 block">Suggested Field Protocol:</span>
                <p className="text-slate-300 text-[11px] leading-relaxed">{selectedIncident.suggestedAction}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
